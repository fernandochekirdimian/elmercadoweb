<?php
include 'docs/resources/connectDb.php'; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>elMercadoWeb.com.ar</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF8">
	<meta name="keywords" content="compra y venta de productos en Santa Fe Argentina y el mundo">
	<meta name="robots" content="venta, ventas, compra, compras, productos, avisos clasificados, rubros, autos, informatica, casas, inmuebles">

	<link rel="SHORTCUT ICON" href="imagenes/dollar2.ico">		

</head>

<frameset rows="219px, *" frameborder="no" framespacing="0">
	<frame name="cabecera" src="cabecera.php" scrolling="no"  />	
	<frame name="contenido" src="contenido.php"  />
	
					
		<noframes>
			<h3>Disculpe su navegador no soporta frames</h3>
		</noframes>	
	
</frameset>

<!--
		<frame name="menu" src="menu.php"  />
 -->

</html>