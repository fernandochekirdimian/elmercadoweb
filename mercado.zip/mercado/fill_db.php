
<?php


class ReferenciaAvisos
{
   

    public function generarPassword ($length = 4)
    {
        $password = "";
        $possible = "abcdfghijklmnopqrstuvwxyz"; 
        $i = 0; 
        while ($i < $length) { 
            $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);
            if (!strstr($password, $char)) { 
                $password .= $char;
                $i++;
            }
        }
        $password1 = "";
        $posible = "0123456789";
        $j = 0;
        
        while ($j < $length) { 
            $char1 = substr($posible, mt_rand(0, strlen($posible)-1), 1);
            if (!strstr($password1, $char1)) { 
                $password1 .= $char1;
                $j++;
            }
        }
        return $password.'-'.$password1;
    }
}

$ref = new ReferenciaAvisos();

$server = 'localhost'; 
$user = 'c1781876_mercado';
$pass = 'doPUpu38zu';
$db = 'c1781876_mercado';
/*
$server = 'localhost'; 
$user = 'root';
$pass = 'admin';
$db = 'mercado';
*/
include('docs/resources/adodb5/adodb.inc.php');
$DB = NewADOConnection('mysqli');
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$DB->Connect($server, $user, $pass, $db);

$arrayClientes = array(
    array('Emiliano', 'Martínez	'),
    array('Nicolás', 'Tagliafico'),
    array('Cristian', 'Romero'),
    array('Nicolás', 'Otamendi'),
    array('Nahuel', 'Molina'),
    array('Rodrigo', 'De Paul'),
    array('Alexis', 'Mac Allister'),
    array('Enzo', 'Fernández'),
    array('Julián', 'Álvarez'),
    array('Lionel', 'Messi'),
    array('Ángel', 'Di María'),
);

$idsClientes = array();

for ($c = 0; $c <= count($arrayClientes); $c++){

    $cli_nombre     = $arrayClientes[$c][0];
    $cli_apellido   = $arrayClientes[$c][1];
    $cli_mail   = $arrayClientes[$c]['nombre'].$arrayClientes[$c]['apellido'].'@elmercadoweb.com.ar';

    $cli_domicilio  = 'Domicilio {$c}';
    $cli_telefono   = '342-4565852';
    $cli_celular    = '342-5457812';
    $cli_provincia  = 'Santa Fe';
    $cli_ciudad     = 'Santa Fe';
    $cli_cp = '3000';
    $cli_pubMail = 1;
    $cli_pubTel =  1;
    $cli_pubCel = 1;
    $cli_pubDom = 1;
    $cli_passwd = '123456';
    $consulta = $DB->Execute("INSERT INTO clientes VALUES (null, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    array(
        $cli_nombre, $cli_apellido, $cli_domicilio, $cli_telefono,
        $cli_celular, $cli_mail, sha1($cli_passwd), $cli_provincia, $cli_ciudad,
        $cli_cp, $cli_pubMail, $cli_pubTel, $cli_pubCel, $cli_pubDom
    ));
    $idsClientes[] = $DB->Insert_ID();
}


$tiposPago = array('Contado', 'Tarjeta de Credito');
$av = array(
        array(3, 1),    
        array(3, 1),    
        array(3, 1),    
        array(3, 1),    
        array(8, 1),
        array(8, 1),
        array(8, 1),
        array(8, 1),
        array(20, 2),
        array(20, 2),
        array(20, 2),
        array(20, 2),
        array(21, 2),
        array(21, 2),
        array(21, 2),
        array(21, 2),
        array(25, 3),
        array(25, 3),
        array(25, 3),
        array(25, 3),
        array(26, 3),
        array(35, 3),
        array(43, 4),
        array(43, 4),
        array(43, 4),
        array(43, 4),
        array(46, 5),
        array(47, 5),
        array(47, 5),
        array(47, 5),
        array(47, 5),
        array(50, 6),
        array(51, 6),
        array(57, 6),
        array(57, 6),
        array(57, 6),
        array(57, 6),
        array(57, 6),
        array(57, 6),
        array(58, 6),
        array(64, 6),
        array(64, 6),
        array(64, 6),
        array(64, 6),
        array(64, 6),
);

$avisosId = array();

for ($j = 0; $j <= count($av); $j++){

    $av_ref = $ref->generarPassword(4);    
    $av_titulo = 'Titulo Aviso'. $av_ref;
    $av_desc = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus';
    $av_coment = '';
    $fechaPublicacion = date('Y-m-d');
    $publicado = 1;
    $av_pubpag = rand(0,1);
    $av_forma_pago = $tiposPago[rand(0,1)];
    $av_precio = rand(1500, 10000);
    $subr_id = $av[$j][0];  
    $cli_id = $idsClientes[rand(1, 11)];  
    $rub_id = $av[$j][1];
    $av_forma_cobro = 1;
    $av_costo = 9;

    $consulta = $DB->Execute("INSERT INTO avisos VALUES(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
    array(
        $av_ref, $av_titulo, $av_desc, $av_coment, $fechaPublicacion, $publicado, $av_pubpag, $av_forma_pago,
        $av_precio, $subr_id, $cli_id, $rub_id, $av_forma_cobro, $av_costo
    ));
    $avisosId[] = $DB->Insert_ID();

    /*for ($i = 0; $i < 3; $i++){			
        $av_img_url = $_POST['img_'.($i+1)];			
        $consulta = $DB->Execute("INSERT INTO imagenes_avisos VALUES(null,?,?)", array($av_img_url, $av_id));
    }*/

}