
<?php


class ReferenciaAvisos
{
   

    public function generarPassword ($length = 4)
    {
        $password = "";
        $possible = "abcdfghijklmnopqrstuvwxyz"; 
        $i = 0; 
        while ($i < $length) { 
            $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);
            if (!strstr($password, $char)) { 
                $password .= $char;
                $i++;
            }
        }
        $password1 = "";
        $posible = "0123456789";
        $j = 0;
        
        while ($j < $length) { 
            $char1 = substr($posible, mt_rand(0, strlen($posible)-1), 1);
            if (!strstr($password1, $char1)) { 
                $password1 .= $char1;
                $j++;
            }
        }
        return $password.'-'.$password1;
    }
}

$ref = new ReferenciaAvisos();

$server = 'localhost'; 
$user = 'root';
$pass = 'admin';
$db = 'mercado';

include('docs/resources/adodb5/adodb.inc.php');
$DB = NewADOConnection('mysqli');
$DB->SetFetchMode(ADODB_FETCH_ASSOC);
$DB->Connect($server, $user, $pass, $db);

$tiposPago = array('Contado', 'Tarjeta de Credito');
$av = array(
        array(
            $ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000),    
            3,
            1,
            1,
            1, rand(3, 9)
        ),    
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 8, 1, 1, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 20, 1, 2, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 21, 1, 2, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 25, 1, 3, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 26, 1, 3, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 35, 1, 3, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 43, 1, 4, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 46, 1, 5, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 47, 1, 5, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 50, 1, 6, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 51, 1, 6, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 57, 1, 6, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 58, 1, 6, 1, rand(3, 9)
        ),
        array($ref->generarPassword(4),
            'Titulo Aviso ', 
            'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, illum. Eos impedit optio hic vitae eveniet eligendi ipsam deserunt vero voluptas natus',
            '',
            date('Y-m-d'),
            1,
            rand(0,1),
            $tiposPago[rand(0,1)],
            rand(1500, 10000), 64, 1, 6, 1, rand(3, 9)
        )
);

for ($j = 0; $j <= count($av); $j++){

    $av_ref = $av[$j][0];    
    $av_titulo = $av[$j][1];
    $av_desc = $av[$j][2];
    $av_coment = $av[$j][3];
    $fechaPublicacion = $av[$j][4];
    $publicado = $av[$j][5];
    $av_pubpag = $av[$j][6];
    $av_forma_pago = $av[$j][7];
    $av_precio = $av[$j][8];
    $subr_id = $av[$j][9];  
    $cli_id = $av[$j][10];  
    $rub_id = $av[$j][11];
    $av_forma_cobro = $av[$j][12];
    $av_costo = $av[$j][13];

    $consulta = $DB->Execute("INSERT INTO avisos VALUES(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
    array(
        $av_ref, $av_titulo, $av_desc, $av_coment, $fechaPublicacion, $publicado, $av_pubpag, $av_forma_pago,
        $av_precio, $subr_id, $cli_id, $rub_id, $av_forma_cobro, $av_costo
    ));
    $av_id = $DB->Insert_ID();

    /*for ($i = 0; $i < 3; $i++){			
        $av_img_url = $_POST['img_'.($i+1)];			
        $consulta = $DB->Execute("INSERT INTO imagenes_avisos VALUES(null,?,?)", array($av_img_url, $av_id));
    }*/

}