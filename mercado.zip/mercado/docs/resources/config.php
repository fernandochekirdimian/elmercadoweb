<?php
$_HOST = "http://localhost/mercado";
$_IMG_TARGET = "imagenes_avisos/";